Thank you very much for buying this pack and supporting me.
You can send me an email and give feedback about the pack. (gikeotawork@gmail.com)
I will be glad if you tell me what you want to see next.

License:

What you can do:
Use in commercial and non-commercial video games and personal projects.
Edit the assets as much as you like for use in projects.
Publish your work using these assets on websites relating to art, games, and similar.

What you can't do:
Resell, repackage or redistribute the assets in original or modified form.
Use the assets or derivatives in logo, trademark, or service mark. 
Include these assets in game making tools, code templates, or NFT/crypto/play to earn projects.
Use the assets in any printed media or physical products.